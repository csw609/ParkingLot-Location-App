package com.example.mom;

public class ReviewData {
        private String parking_reviewID;
        private String parking_review;

        public String getParking_reviewID(){
        return parking_reviewID;
    }

        public String getParking_review(){
        return parking_review;
    }



        public void setParking_reviewID(String parking_reviewID){ this.parking_reviewID=parking_reviewID; }

        public void setParking_review(String parking_review){
        this.parking_review=parking_review;
    }
}
